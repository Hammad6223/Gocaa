import LoginController from "./LoginController.js";
import {ForgetController} from "./ForgetController.js";
import SignupController from "./SignupController.js"; 
import DataReset from "./ResetPassword.js";



export {LoginController,ForgetController ,SignupController,DataReset}