import DataProfile from "./ProfileController.js";
import DataDealer from "./Dealer.js";
import DataVehicle from "./Vehicle.js";
import DataDriver from "./Driver.js";
import DataService from "./Service.js";




export {DataProfile,DataDealer,DataVehicle,DataDriver,DataService}  

