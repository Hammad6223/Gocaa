import DataProfile from "./ProfileController.js";
import Home from "./Home.js";
import Search from "./Search.js";





export {DataProfile,Home,Search}